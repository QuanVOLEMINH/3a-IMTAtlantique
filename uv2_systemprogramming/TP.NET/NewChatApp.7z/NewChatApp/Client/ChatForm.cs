﻿using RemotingInterface;
using System;
using System.Collections.Generic;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Threading;
using System.Windows.Forms;

namespace Client
{
    public partial class ChatForm : Form
    {
        private IRemotChaine LeRemot;
        private List<string> onlineUsers;
        private Thread th;

        public ChatForm()
        {
            InitializeComponent();

            // création d'un canal recepteur TCP
            TcpChannel canal = new TcpChannel();

            // enregistrement du canal
            ChannelServices.RegisterChannel(canal);

            LeRemot = (IRemotChaine)Activator.GetObject(
                typeof(IRemotChaine), "tcp://localhost:12345/Serveur");

            onlineUsers = new List<string>();

        }

        private void InitView(string machineName, string port, string serverName, string userName)
        {
            machinename_textbox.Text = machineName;
            machinename_textbox.Enabled = false;

            port_textbox.Text = port;
            port_textbox.Enabled = false;

            servername_textbox.Text = serverName;
            servername_textbox.Enabled = false;

            chat_textbox.ReadOnly = true;
            member_textbox.ReadOnly = true;

            AddMemberToView();

        }

        private void disconnect_btn_Click(object sender, EventArgs e)
        {
        }

        private void sendmessage_btn_Click(object sender, EventArgs e)
        {
            string toSend = "quan: ";
            LeRemot.AddText(toSend + message_textbox.Text);
        }

        private void AddMemberToView()
        {
            onlineUsers = LeRemot.GetMembers();
            onlineUsers.ForEach(u =>
            {
                member_textbox.AppendText(u);
                member_textbox.AppendText(Environment.NewLine);
            });
        }

        private void login_btn_Click(object sender, EventArgs e)
        {
            InitializeRemoteServer();
            LeRemot.JoinChatRoom("quan");
            th = new Thread(new ThreadStart(PollServer));

            
            th.Start();
        }

        private void InitializeRemoteServer()
        {
            RemotingConfiguration.RegisterWellKnownClientType(typeof(IRemotChaine), "http://localhost:12345/Serveur");
        }
        private void PollServer()
        {
            while (true)
            {
                Thread.Sleep(1000);
                List<string> users = LeRemot.GetMembers();
                listBox1.Items.Clear();
                foreach (string userName in users)
                {
                    listBox1.Items.Add(userName);
                }
                string sessionText = LeRemot.ChatSession();
                chat_textbox.Clear();
                chat_textbox.Text = sessionText;
            }
        }
    }
}
