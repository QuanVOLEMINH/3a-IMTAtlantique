﻿namespace Client
{
    partial class ChatForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.disconnect_btn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.machinename_textbox = new System.Windows.Forms.TextBox();
            this.port_textbox = new System.Windows.Forms.TextBox();
            this.servername_textbox = new System.Windows.Forms.TextBox();
            this.member_textbox = new System.Windows.Forms.TextBox();
            this.chat_textbox = new System.Windows.Forms.TextBox();
            this.message_textbox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.sendmessage_btn = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.login_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // disconnect_btn
            // 
            this.disconnect_btn.Location = new System.Drawing.Point(197, 401);
            this.disconnect_btn.Name = "disconnect_btn";
            this.disconnect_btn.Size = new System.Drawing.Size(141, 46);
            this.disconnect_btn.TabIndex = 0;
            this.disconnect_btn.Text = "Deconnexion";
            this.disconnect_btn.UseVisualStyleBackColor = true;
            this.disconnect_btn.Click += new System.EventHandler(this.disconnect_btn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Machine";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(291, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Porte";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(454, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Nom du serveur";
            // 
            // machinename_textbox
            // 
            this.machinename_textbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.machinename_textbox.Location = new System.Drawing.Point(88, 8);
            this.machinename_textbox.Name = "machinename_textbox";
            this.machinename_textbox.Size = new System.Drawing.Size(183, 22);
            this.machinename_textbox.TabIndex = 2;
            // 
            // port_textbox
            // 
            this.port_textbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.port_textbox.Location = new System.Drawing.Point(344, 6);
            this.port_textbox.Name = "port_textbox";
            this.port_textbox.Size = new System.Drawing.Size(100, 22);
            this.port_textbox.TabIndex = 2;
            // 
            // servername_textbox
            // 
            this.servername_textbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.servername_textbox.Location = new System.Drawing.Point(580, 6);
            this.servername_textbox.Name = "servername_textbox";
            this.servername_textbox.Size = new System.Drawing.Size(189, 22);
            this.servername_textbox.TabIndex = 2;
            // 
            // member_textbox
            // 
            this.member_textbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.member_textbox.Location = new System.Drawing.Point(580, 105);
            this.member_textbox.Multiline = true;
            this.member_textbox.Name = "member_textbox";
            this.member_textbox.Size = new System.Drawing.Size(189, 218);
            this.member_textbox.TabIndex = 3;
            // 
            // chat_textbox
            // 
            this.chat_textbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chat_textbox.Location = new System.Drawing.Point(16, 74);
            this.chat_textbox.Multiline = true;
            this.chat_textbox.Name = "chat_textbox";
            this.chat_textbox.Size = new System.Drawing.Size(428, 187);
            this.chat_textbox.TabIndex = 3;
            // 
            // message_textbox
            // 
            this.message_textbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.message_textbox.Location = new System.Drawing.Point(16, 305);
            this.message_textbox.Multiline = true;
            this.message_textbox.Name = "message_textbox";
            this.message_textbox.Size = new System.Drawing.Size(428, 74);
            this.message_textbox.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(576, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "Membres";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 282);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Tapez votre message";
            // 
            // sendmessage_btn
            // 
            this.sendmessage_btn.Location = new System.Drawing.Point(16, 401);
            this.sendmessage_btn.Name = "sendmessage_btn";
            this.sendmessage_btn.Size = new System.Drawing.Size(136, 46);
            this.sendmessage_btn.TabIndex = 4;
            this.sendmessage_btn.Text = "Envoie";
            this.sendmessage_btn.UseVisualStyleBackColor = true;
            this.sendmessage_btn.Click += new System.EventHandler(this.sendmessage_btn_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(579, 345);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(190, 95);
            this.listBox1.TabIndex = 5;
            // 
            // login_btn
            // 
            this.login_btn.Location = new System.Drawing.Point(75, 45);
            this.login_btn.Name = "login_btn";
            this.login_btn.Size = new System.Drawing.Size(75, 23);
            this.login_btn.TabIndex = 6;
            this.login_btn.Text = "button1";
            this.login_btn.UseVisualStyleBackColor = true;
            this.login_btn.Click += new System.EventHandler(this.login_btn_Click);
            // 
            // ChatForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.login_btn);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.sendmessage_btn);
            this.Controls.Add(this.message_textbox);
            this.Controls.Add(this.chat_textbox);
            this.Controls.Add(this.member_textbox);
            this.Controls.Add(this.servername_textbox);
            this.Controls.Add(this.port_textbox);
            this.Controls.Add(this.machinename_textbox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.disconnect_btn);
            this.Name = "ChatForm";
            this.Text = "Chat Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button disconnect_btn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox machinename_textbox;
        private System.Windows.Forms.TextBox port_textbox;
        private System.Windows.Forms.TextBox servername_textbox;
        private System.Windows.Forms.TextBox member_textbox;
        private System.Windows.Forms.TextBox chat_textbox;
        private System.Windows.Forms.TextBox message_textbox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button sendmessage_btn;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button login_btn;
    }
}